class Configuration {
  static const apiKey = "AIzaSyD8-30gsoaUkDRZ8wY0Buq9J5Hqs8x9pDs";
  static const authDomain = "warriors-of-fate-6bb17.firebaseapp.com";
  static const databaseURL =
      "https://warriors-of-fate-6bb17-default-rtdb.firebaseio.com";
  static const projectId = "warriors-of-fate-6bb17";
  static const storageBucket = "warriors-of-fate-6bb17.appspot.com";
  static const messagingSenderId = "633190403823";
  static const appId = "1:633190403823:web:341103bfa7bf03b8ed151a";
}
